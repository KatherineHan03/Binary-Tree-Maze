package project5;
import java.util.*;
import java.io.*;
/**
 * The generic BST<E> class extends Comparable<E> and implements Iterable<E>.
 * In the class, iterator is implemented for inorder, preorder, and postorder.
 * This class contains a protected nested Node class, which has data fields such as 
 * E e (data), Node left, Node right, boolean found (for the remove method).
 * In addition to the BST constructors, there are multiple methods in the BST<E> class
 * that have different binary search tree functions that are able to manipulate the tree. 
 * @author Katherine Han
 * @version 04/30/2023
 */
public class BST<E extends Comparable<E>> implements Iterable<E>{
	private int size;
	private Node root;
	private boolean found = false;
	/**
	 * This is the nested, protected Node class that has an E e variable to hold its data and
	 * a left and right to point to its children to hold the height of the node (set to 1).
	 * @author Katherine Han
	 * @version 04/30/2023
	 */
	protected class Node 
	{
		protected E e;
		protected Node left;
		protected Node right;
		/**
		 * This is the Node constructor that has the generic type e (data)
		 * @param E e, the data that the node holds
		 */
		public Node(E e)
		{
			this.e = e;
		}
	}
	/**
	 * This is a getter method to access the node data in the Maze class.
	 * @param Node node, the node that has the data that is being accessed.
	 * @return node.e, the node's data.
	 */
	protected E getElement(Node node)
	{
		return node.e;
	}
	/**
	 * Constructs a new, empty tree, sorted according to the natural ordering of its elements.
	 */
	public BST()
	{
		root = null;
	}
	/**
	 * Constructs a new tree containing the elements in the specified collection, sorted according to the natural ordering of its elements.
	 * @param E[] Collection, the array of generic object type values that you are forming a balanced tree from.
	 */
	public BST(E[] Collection)
	{
		root = null;
		Arrays.sort(Collection);
		BSTHelp(Collection, 0, Collection.length);
	}
	/**
	 * This is the helper method that finds and adds the middle of the array to the tree and recursively calls itself with its new middles (after splitting).
	 * @param E[] Collection, the array of generic object type values that you are forming a balanced tree from.
	 * @param int start, the beginning index of the array
	 * @param int end, the ending index of the array
	 */
	private void BSTHelp(E[] collection, int start, int end)
	{
		int mid = (start+end) / 2;
		//base case: if the start overtakes or is equal to the end
		if(start >= end) 
		{
			this.add(collection[0]);
			return;
		}
		this.add(collection[mid]);
		//splits the array
		BSTHelp(collection, 0, mid); 
		BSTHelp(collection, mid + 1, end);
	}
	/**
	 * The toArray(String type) calls either the inorder, preorder, or postorder methods depending on the input
	 * and produces an ArrayList based on this.
	 * @param String type, an identifier for if toArray() is being used for an inorder, preorder, or postorder list.
	 * @return list, this is the ArrayList that is produced that is either inorder, preorder, or postorder.
	 */
	public ArrayList<E> toArray(String type)
	{
		if(root == null)
		{
			return null;
		}
		ArrayList<E> list = new ArrayList<E>();
		if(type.equals("inorder"))
		{
			//calls inorder method
			inorder(list, root); 
		}
		else if(type.equals("preorder"))
		{
			//calls preorder method
			preorder(list, root); 
		}
		else if(type.equals("postorder"))
		{
			//calls postorder method
			postorder(list, root); 
		}
		return list;
	}
	/**
	 * This method recursively edits the ArrayList<E> list parameter to have the parameter nodes inorder.
	 * @param ArrayList<E> list, the list that is filled with the nodes in the other parameter. 
	 * @param Node node, this parameter is the root node
	 */
	private void inorder(ArrayList<E> list, Node node)
	{
		if(node == null)
		{
			return;
		}
		//left, root, right
		inorder(list, node.left);
		list.add(node.e);
		inorder(list, node.right);
	}
	/**
	 * This method recursively edits the ArrayList<E> list parameter to have the parameter nodes preorder.
	 * @param ArrayList<E> list, the list that is filled with the nodes in the other parameter. 
	 * @param Node node, this parameter is the root node
	 */
	private void preorder(ArrayList<E> list, Node node)
	{
		if(node == null)
		{
			return;
		}
		//root, left, right
		list.add(node.e);
		preorder(list, node.left);
		preorder(list, node.right);
	}
	/**
	 * This method recursively edits the ArrayList<E> list parameter to have the parameter nodes postorder.
	 * @param ArrayList<E> list, the list that is filled with the nodes in the other parameter. 
	 * @param Node node, this parameter is the root node
	 */
	private void postorder(ArrayList<E> list, Node node)
	{
		if(node == null)
		{
			return;
		}
		//left, right, root
		postorder(list, node.left);
		postorder(list, node.right);
		list.add(node.e);
	}
	/**
	 * This is a nested iterator class that implements Iterator<E>. This class has
	 * two private variables that represent the ArrayList<E> list and int curr.
	 * This class has a constructor and implements the iterator methods such as hasNext(), next(), and remove
	 * @author Katherine Han
	 * @version 04/30/2023
	 */
	private class TreeIterator<E> implements Iterator<E>
	{
		private ArrayList<E> list;
		private int curr;
		/**
		 * This constructor uses a String iterate parameter to create a list with the toArray() method.
		 * It sets int curr to 0.
		 * @param String iterate, used as the toArray parameter when calling toArray.
		 */
		public TreeIterator(String iterate)
		{
			this.list = (ArrayList<E>) BST.this.toArray(iterate);
			curr = 0;
		}
		/**
		 * The hasNext() method checks if there is a next element in the list.
		 * @return a boolean of whether the current element is less that the total number of elements in the list
		 */
		public boolean hasNext() 
		{
			return curr < list.size();
		}
		/**
		 * The next() method accesses the next element in the list and moves int curr up.
		 * @return the element at curr++.
		 */
		public E next()
		{
			return list.get(curr++);
		}
		/**
		 * @throws UnsupportedOperationException when called
		 */
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
	/**
	 * Inspiration Credit: Class Slides
	 * Adds the specified element to this set if it is not already present. 
	 * More formally, adds the specified element e to this tree if the set 
	 * contains no element e2 such that Objects.equals(e, e2). 
	 * If this set already contains the element, the call leaves the set unchanged and returns false.
	 * @param E e, element to be added to this set
	 * @return true if this set did not already contain the specified element 
	 * @throws NullPointerException, if the specified element is null and this set uses natural ordering, or its comparator does not permit null elements
	 */
	public boolean add (E e) {
		if (root == null ) 
		{
			root = new Node (e);
			//increment size when adding a Node
			size++;
			//so the method will return true
			return true;
		}
		Node current = root;
		while (current != null ) 
		{
		//add to the left if the input data is smaller than the current node
			if (e.compareTo(current.e) < 0) 
			{
				if (current.left == null ) 
				{
					current.left = new Node (e);
					//increment size - added a new node into the tree
					size++;
					return true;
				}
				else 
				{
					current = current.left;
				}
			}
			//add to the right if the input data is bigger than the current node
			else if (e.compareTo(current.e) > 0 ) 
			{
				if (current.right == null ) 
				{
					current.right = new Node (e);
					size++;
					return true;
				}
				else 
				{
					current = current.right;
				}
			}
			else 
			{ 
				//no duplicate values in BST
				return false; 
			}
		}
		//we should never get to this line 
        return false; 
   }
	/** 
	 * Inspiration credit: BST class on ED
	 * Removes the specified element from this tree if it is present. More formally, 
	 * removes an element e such that Objects.equals(o, e), if this tree contains such an element. 
	 * Returns true if this tree contained the element (or equivalently, if this tree changed as a result of the call). 
	 * (This tree will not contain the element once the call returns.)
	 * @param o - object to be removed from this set, if present
	 * @return true if this set contained the specified element 
	 * @throws ClassCastException - if the specified object cannot be compared with the elements currently in this tree
	 * @throws NullPointerException - if the specified element is null
	 */
	public boolean remove(Object o)
	{
		root = recRemove((E) o, root);
		if (found) 
		{
			//decrease size
			size--; 
		}
		return found;
	}
	/**
	 * Inspiration credit: BST class on ED
	 * Actual recursive implementation of remove method: find the node to remove.
	 * This function recursively finds and eventually removes the node with the target element 
     * and returns the reference to the modified tree to the caller. 
	 * @param target object to be removed from this tree, if present
     * @param node node at which the recursive call is made 
	 */
	private Node recRemove(E target, Node node)
	{
		//if the node is null, set the found private variable to false;
		if (node == null)  {  
			found = false;
            return node; 
        }
		//the compareTo value
        int comp = target.compareTo(node.e); 
        if (comp < 0)       
        	//recursively call the method to node.left/node.right
			node.left = recRemove(target, node.left); 
		else if (comp > 0)  
			node.right = recRemove(target, node.right );
		else {    
			//call removeNode with the node parameter
			node = removeNode(node); 
			//set found to true
			found = true; 
		}
		return node;
	}
	/**
	 * Inspiration credit: BST class on ED
	 * Actual recursive implementation of remove method: perform the removal.
	 * @param target the item to be removed from this tree
	 * @return a reference to the node itself, or to the modified subtree
	 */
	private Node removeNode(Node node)
	{
		E data;
		//if the left child is null, go right
		if (node.left == null) 
			return node.right ; 
		else if (node.right  == null) 
			return node.left;
		else {                
			//get the predecessor
			data = getPredecessor(node.left); 
			node.e = data; 
			node.left = recRemove(data, node.left);
			return node; 
		}
	}
	/**
	 * This method obtains the predecessor of the node input.
	 * Inspiration credit: Class ED implementation
	 * @param Node node - the input node of the tree
	 * @return the data of the predecessor node
	 * @throws NullPointerException - if the specified element is null
	 */
	private E getPredecessor(Node node) {
		Node current = node.left;
		//if the node's right child is not null, go to the right
		while(current.right != null) { 
			current = current.right;
		}
		return current.e;
	}
	/**
	 * Removes all of the elements from this set. The set will be empty after this call returns.
	 */
	public void clear()
	{
		root = null;
		size = 0;
	}
	/**
	 * Returns true if this set contains the specified element. 
	 * More formally, returns true if and only if this set contains an element e such that Objects.equals(o, e).
	 * @param o - object to be checked for containment in this set
	 * @return true if this set contains the specified element
	 * @throws ClassCastException - if the specified object cannot be compared with the elements currently in the set
	 * @throws NullPointerException - if the specified element is null and this set uses natural ordering, or its comparator does not permit null elements
	 */
	public boolean contains(Object o)
	{
		Node n = root;
		return checkContain((E)o, root);
	}
	/**
	 * This is the helper method for the contains() method
	 * @param E data - the input data value
	 * @param Node n - the root node
	 * @return true if this set contains the specified element
	 */
	private boolean checkContain(E data, Node n)
	{
		if(n == null)
		{
			return false;
		}
		if(data.compareTo(n.e) < 0)
		{
			//if the input is smaller, call the method again with the left child
			return checkContain(data, n.left); 
		}
		else if(data.compareTo(n.e) > 0)
		{
			//if the input is larger, call the method again with the right child
			return checkContain(data, n.right); 
		}
		else
		{
			return true;
		}
	}
	/**
	 * Returns the number of elements in this tree.
	 * @return the number of elements in this tree
	 */
	public int size()
	{
		return size;
	}
	/**
	 * Returns true if this set contains no elements.
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty()
	{
		if(root == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * Returns the height of this tree. The height of a leaf is 1. 
	 * The height of the tree is the height of its root node.
	 * @return the height of this tree or zero if the tree is empty
	 */
	public int height()
	{
		//if tree is empty return 0
		if(isEmpty())
		{
			return 0;
		}
		else
		{
			//call the findHeight method with the root as the node parameter
			return findHeight(this.root);
		}
	}
	/**
	 * Returns the height of this tree. The height of a leaf is 1. 
	 * The height of the tree is the height of its root node.
	 * @return the height of this tree or zero if the tree is empty
	 */
	private int findHeight(Node node)
	{
		if(node == null)
		{
			return 0;
		}
		return Math.max(findHeight(node.left), findHeight(node.right)) + 1;
	}
	/**
	 * Returns an iterator over the elements in this tree in ascending order.
	 * @return an iterator over the elements in this set in ascending order
	 */
	public Iterator<E> iterator()
	{
		return new TreeIterator("inorder");
	}
	/**
	 * Returns an iterator over the elements in this tree in order of the preorder traversal.
	 * @return an iterator over the elements in this tree in order of the preorder traversal
	 */
	public Iterator<E> preorderIterator()
	{
		return new TreeIterator("preorder");
	}
	/**
	 * Returns an iterator over the elements in this tree in order of the postorder traversal.
	 * @return an iterator over the elements in this tree in order of the postorder traversal
	 */
	public Iterator<E> postorderIterator()
	{
		return new TreeIterator("postorder");
	}
	/**
	 * Returns the element at the specified position in this tree. The order of the indexed elements is the same as provided by this tree's iterator. 
	 * The indexing is zero based (i.e., the smallest element in this tree is at index 0 and the largest one is at index size()-1).
	 * @param index - index of the element to return
	 * @return the element at the specified position in this tree
	 * @throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= size())
	 */
	public E get(int index)
	{
		ArrayList<E> list = toArray("inorder");
		return list.get(index);
	}
	/**
	 * Returns the least element in this tree greater than or equal to the given element, or null if there is no such element.
	 * @param e - the value to match
	 * @return the least element greater than or equal to e, or null if there is no such element
	 * @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException - if the specified element is null
	 */
	public E ceiling(E e)
	{
		Node curr = root;
		E ceiling = null;
		while(curr != null)
		{
			//if the input is equal to the current data, return
			if(Objects.equals(curr.e, e)) 
			{
				return curr.e;
			}
			//if the input is bigger, go to the right
			if(curr.e.compareTo(e) < 0) 
			{
				curr = curr.right;
			}
			//if the input is smaller, go to the right
			else if(curr.e.compareTo(e) > 0) 
			{
				if(ceiling == null)
				{
					//set the ceiling to the current if there is no ceiling value
					ceiling = curr.e; 
				}
				//set the ceiling to the new current
				else if(curr.e.compareTo(ceiling) < 0) 
				{
					ceiling = curr.e;
				}
				curr = curr.left;
			}
		}
		return ceiling;
	}
	/**
	 * Returns the greatest element in this set less than or equal to the given element, or null if there is no such element.
	 * @param e - the value to match
	 * @return the greatest element less than or equal to e, or null if there is no such element
	 * @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException - if the specified element is null
	 */
	public E floor(E e)
	{
		Node curr = root;
		E floor = null;
		while(curr != null)
		{
			//if the input is equal to the current data, return
			if(Objects.equals(curr.e, e)) 
			{
				return curr.e;
			}
			//if the input is bigger, go to the right
			if(curr.e.compareTo(e) < 0) 
			{
				//set the floor to the current if there is no floor value
				if(floor == null) 
				{
					floor = curr.e; 
				}
				//set the floor to the new current
				else if(curr.e.compareTo(floor) > 0) 
				{
					floor = curr.e;
				}
				curr = curr.right;
			}
			else if(curr.e.compareTo(e) > 0)
			{
				curr = curr.left;
			}
		}
		return floor;
	}
	/**
	 * Returns the first (lowest) element currently in this tree.
	 * @return the first (lowest) element currently in this tree
	 * @throws NoSuchElementException - if this set is empty
	 */
	public E first() throws NoSuchElementException
	{
		if(isEmpty())
		{
			throw new NoSuchElementException("no such element");
		}
		Node curr = root;
		// keep going to the left of the tree until you get to the leftmost node
		while(curr.left != null) 
		{
			curr = curr.left;
		}
		return curr.e;
	}
	/**
	 * Returns the last (highest) element currently in this tree.
	 * @return the last (highest) element currently in this tree
	 * @throws NoSuchElementException - if this set is empty
	 */
	public E last() throws NoSuchElementException
	{
		if(isEmpty())
		{
			throw new NoSuchElementException("no such element");
		}
		Node curr = root;
		// keep going to the right of the tree until you get to the rightmost node 
		while(curr.right != null) 
		{
			curr = curr.right;
		}
		return curr.e;
	}
	/**
	 * Returns the greatest element in this set strictly less than the given element, or null if there is no such element.
	 * @param e - the value to match
	 * @return the greatest element less than e, or null if there is no such element
	 * @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException - if the specified element is null
	 */
	public E lower(E e)
	{
		Node curr = root;
		E lower = null;
		while(curr != null)
		{
			//if the current node data is equal to the input value, make the current the left child
			if(Objects.equals(curr.e, e))
			{
				curr = curr.left;
			}
			//if the current node data is less than the input value, set lower and make current the right child
			else if(curr.e.compareTo(e) < 0)
			{
				if(lower == null)
				{
					lower = curr.e;
				}
				else if(curr.e.compareTo(lower) > 0)
				{
					lower = curr.e;
				}
				curr = curr.right;
			}
			//if the current node data is greater than the input value, make the current the left child
			else if(curr.e.compareTo(e) > 0)
			{
				curr = curr.left;
			}
		}
		return lower;
	}
	/**
	 * Returns the least element in this tree strictly greater than the given element, or null if there is no such element.
	 * @param e - the value to match
	 * @return the least element greater than e, or null if there is no such element
	 * @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException - if the specified element is null
	 */
	public E higher(E e)
	{
		Node curr = root;
		E higher = null;
		while(curr != null)
		{
			//if the current node data is equal to the input value, make current the right child
			if(Objects.equals(curr.e, e))
			{
				curr = curr.right;
			}
			//if the current node data is less than the input value, make current the right child
			else if(curr.e.compareTo(e) < 0)
			{
				curr = curr.right;
			}
			//if the current node data is greater than the input value, set higher and make current the left child
			else if(curr.e.compareTo(e) > 0)
			{
				if(higher == null)
				{
					higher = curr.e;
				}
				else if(curr.e.compareTo(higher) < 0)
				{
					higher = curr.e;
				}
				curr = curr.left;
			}
		}
		return higher;
	}
	/**
	 * Inspiration credit: Class Ed implementation
	 * Compares the specified object with this tree for equality. Returns true if the given object is also a tree, the two trees have the same size, and every member of the given tree is contained in this tree.
	 * @param obj - object to be compared for equality with this tree
	 * @return true if the specified object is equal to this tree
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null) 
		{
			return false; 
		}
		//if the input is equal to the class object return true
        if (obj == this) 
        {
        	return true; 
        }
        if (!(obj instanceof BST))
        {
        	return false ; 
        }
        BST <?> bst = (BST <?>) obj;  
        if (this.size() != bst.size()) 
        {
        	return false; 
       	}
        //calls the inorder toArray method
        ArrayList<E> thisList = this.toArray("inorder");
        ArrayList<?> bstList = bst.toArray("inorder");
        for ( int i = 0; i < thisList.size(); i++ ) 
        {
        	//if they don't equal return false
            if ( !thisList.get(i).equals(bstList.get(i))) 
            {
                return false;
            }
        }
        return true; 
	}
	/**
	 * This is the method that gets all the possible paths of a tree (reach root to leaf)
	 * This method is used in the Maze class but written in the BST<E> class to access these values
	 * @return ArrayList<ArrayList<Node>> allPaths, an ArrayList of ArrayLists that hold the paths
	 */
	protected ArrayList<ArrayList<Node>> getPaths()
	{
		if(root == null)
		{
			return null;
		}
		//nested ArrayList of paths
		ArrayList<ArrayList<Node>> allPaths = new ArrayList<ArrayList<Node>>(); 
		//single path ArrayList
		ArrayList<Node> onePath = new ArrayList<Node>();
		//set current to the root
		Node curr = this.root;
		allPaths = findPaths(allPaths, curr, onePath);
		return allPaths;
	}
	/**
	 * This is the helper method that recursively gets all the possible paths of a tree (reach root to leaf)
	 * @return ArrayList<ArrayList<Node>> allPaths, an ArrayList of ArrayLists that hold the paths
	 */
	private ArrayList<ArrayList<Node>> findPaths(ArrayList<ArrayList<Node>> allPaths, Node node, ArrayList<Node> onePath)
	{
		if(node == null)
		{
			return allPaths;
		}
		//add the input node to the single path ArrayList
		onePath.add(node); 
		//if there are no children
		if(node.left == null && node.right == null) 
		{
			//add the path ArrayList to the nested ArrayList of paths
			allPaths.add(onePath); 
			return allPaths;
		}
		else
		{
			//recursively call through creating a new ArrayList<>(onePath) and node.left/node.right
			findPaths(allPaths, node.left, new ArrayList<>(onePath)); 
			findPaths(allPaths, node.right, new ArrayList<>(onePath));
		}
		return allPaths;
	}
	/**
	 * Returns a string representation of this tree. The string representation consists of a list of the tree's elements 
	 * in the order they are returned by its iterator (inorder traversal), enclosed in square brackets ("[]"). 
	 * Adjacent elements are separated by the characters ", " (comma and space). Elements are converted to strings as by String.valueOf(Object).
	 * @return a string representation of this collection
	 */
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		Iterator<E> iterator = iterator();
		while(iterator.hasNext())
		{
			//while the iterator has the next element, append the brackets and the element
			sb.append("["); 
			sb.append(iterator.next());
			sb.append("]");
			//after it goes to the next element, if it has a next element, print a comma
			if(iterator.hasNext()) 
			{
				sb.append(", ");
			}
		}
		//convert StringBuilder to a String to return
		return sb.toString();
	}
	/**
	 * Inspiration credit: Class Ed implementation
	 * Produces tree like string representation of this tree. Returns a string representation of this tree in a tree-like format. 
	 * The string representation consists of a tree-like representation of this tree. Each node is shown in its own line with the indentation showing the depth of the node in this tree. 
	 * The root is printed on the first line, followed by its left subtree, followed by its right subtree.
	 * @return string containing tree-like representation of this tree.
	 */
	public String toStringTreeFormat()
	{
		StringBuffer sb = new StringBuffer();
		//call the toStringTree method with the StringBuffer object, the root, and a level of 0
		toStringTree(sb, root, 0);
		return sb.toString();
	}
	/**
	 * Inspiration credit: Class Ed implementation
	 * The helper method that produces tree like string representation of this tree. Returns a string representation of this tree in a tree-like format. 
	 * The string representation consists of a tree-like representation of this tree. Each node is shown in its own line with the indentation showing the depth of the node in this tree. 
	 * The root is printed on the first line, followed by its left subtree, followed by its right subtree.
	 * @param StringBuffer sb - the StringBuffer that holds the tree visualization
	 * @param Node node - the root node
	 * @param int level - level of the node
	 */
	public void toStringTree(StringBuffer sb, Node node, int level)
	{
		//for levels that are greater than the root, add the indentation and the visualization dashes
		if(level > 0)
		{
			for(int i = 0; i < level - 1; i++)
			{
				sb.append("	");
			}
			sb.append("|--");
		}
		if(node == null)
		{
			//if no children, add null and a new line to the StringBuilder
			sb.append("null\n");
			return;
		}
		else
		{
			//add the node data to the StringBuilder
			sb.append(node.e + "\n");
		}
		//recursive call to the next level and node.left/right
		toStringTree(sb, node.left, level + 1); 
		toStringTree(sb, node.right, level + 1);
	}
}