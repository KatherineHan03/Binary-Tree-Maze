package project5;

import java.io.*;
import java.util.*;
/**
 * The BinaryTreeMaze class is the main class to run the program. 
 * This class uses the command line argument to parse the input file's text
 * and handles any exceptions/throws errors.
 * @author Katherine Han
 * @version 04/30/2023
 */
public class BinaryTreeMaze {
	/**
	 * Inspiration credit to Joanna Klukowska in Project 1's ColorConverter class
	 */
	public static void main(String[] args) 
	{
		//checks if file name or file is valid
		if (args.length == 0 ) {
			System.err.println("need file name as an argument");
			System.exit(1);
		}
		
		File file = new File(args[0]); 
		//tests if the file exists and is readable
		if (!file.exists()){
			System.err.println("file doesn't exist");
			System.exit(1);
		}
		if (!file.canRead()){
			System.err.println("file unable to be opened");
			System.exit(1);
		}
		
		Scanner input = null;
		//try catch to check if the file can be opened
		try {
			input = new Scanner (file) ;
		} catch (FileNotFoundException e) {
			System.err.println("file can't be opened");
			System.exit(1);
		}
		//create a new Maze object
		Maze tree = new Maze(); 
		String line = null; 
		Scanner parseLine = null; 
		String label = null;
		String lifePoints = null; 
		//create a new MazeNode object and set to null
		MazeNode current = null;
		//parse the input file line by line and set the Maze object to the lifePoints and label in the input file
		while (input.hasNextLine()) {
			try { 
				//parse the input text file and set the pre-space value to the label and the post-space value to the lifePoints
				line = input.nextLine(); 
				parseLine = new Scanner(line);
				parseLine.useDelimiter(" "); 
				label = parseLine.next();
				lifePoints = parseLine.next();
			}
			catch (NoSuchElementException ex ) {
				System.err.println(line);
				continue; 	
			}
			try {
				//set the current with the parsed label and lifePoints
				current = new MazeNode(label, Integer.parseInt(lifePoints));
				//add this MazeNode to the Maze tree object
				tree.add(current); 
			}
			catch (IllegalArgumentException ex ) {
			}
		}	
		//call the validPaths method in the Maze class
		tree.validPaths();
	}	
}