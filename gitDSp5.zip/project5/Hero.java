package project5;
/**
 * The Hero class represents the hero that goes through the maze and collects life points.
 * This class has a private int variable to hold the life points, as well as a getter method to access these lifePoints.
 * The other three methods in this class are methods to manipulate the life points according to the hero.
 * @author Katherine Han
 * @version 04/30/2023
 */
public class Hero {
	private int lifePoints;
	/**
	 * Hero constructor to set the lifePoints to 0
	 */
	public Hero()
	{
		this.lifePoints = 0;
	}
	/**
	 * Getter method for the lifePoints
	 * @return lifePoints
	 */
	public int getLifePoints()
	{
		return lifePoints;
	}
	/**
	 * Method to set the lifePoints to 0
	 */
	public void resetLives()
	{
		lifePoints = 0;
	}
	/**
	 * Method to decrease the lifePoints by 1
	 */
	public void losePoint()
	{
		lifePoints--;
	}
	/**
	 * Method to increase the lifePoints by the amount in the node
	 */
	public void gainPoint(int points)
	{
		lifePoints += points;
	}
	/**
	 * Method to check if the hero has enough lifePoints
	 * @return true if the lifePoints are greater than 0
	 */
	public boolean enoughLife()
	{
		return lifePoints > 0;
	}
}
