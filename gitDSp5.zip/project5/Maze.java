package project5;

import java.util.*;
/**
 * The Maze class represents a maze of type MazeNode.
 * This class has two methods that finds all the valid paths for the hero to go through.
 * These paths must have nodes that contain life points that sustain the hero throughout the entire path.
 * In addition to this, the path's last node must not be a trap door. It has to be at the bottom level.
 * This class inherits from BST<MazeNode> and has a constructor that inherits from the super class.
 * It has four private ArrayLists that represent different paths or lists of paths.
 * @author Katherine Han
 * @version 04/30/2023
 */
public class Maze extends BST<MazeNode>{
	private ArrayList<ArrayList<Node>> paths;
	private ArrayList<ArrayList<Node>> longPaths;
	private ArrayList<Node> oneLongPath;
	private ArrayList<ArrayList<Node>> validPathList;
	/**
	 * Maze constructor that calls the super constructor
	 */
	public Maze(){
		super();
	}
	/**
	 * This method finds all the valid paths out of all the paths of the tree
	 * It compares if the size is equal to the height, stores those paths in an ArrayList (prevent going to trap doors),
	 * then finds all the paths that have adequate life points for the hero to go to the end
	 */
	public void validPaths()
	{
		//all paths for the tree
		this.paths = super.getPaths();
		//new Hero object
		Hero hero1 = new Hero(); 
		//nested ArrayList of ArrayLists that hold the paths that have the same size as the height
		longPaths = new ArrayList<ArrayList<Node>>(); 
		//ArrayList of a single path from longPaths
		oneLongPath = new ArrayList<Node>(); 
		//ArrayList of valid sized paths that have enough lifePoints for the hero
		longPaths.add(oneLongPath);
		validPathList = new ArrayList<ArrayList<Node>>(); 
		for(int i = 0; i < paths.size(); i++)
		{
			ArrayList<Node> aPath = paths.get(i);
			if(aPath.size() == this.height())
			{
				//if it is the same number as height, add
				longPaths.add(aPath); 
			}
		}
		
		for(int i = 0; i < longPaths.size(); i++)
		{
			//set oneLongPath ArrayList to the element i of longPaths
			oneLongPath = longPaths.get(i);
			for(int j = 0; j < oneLongPath.size(); j++)
			{
				//the node in the path at element j
				Node area = oneLongPath.get(j);
				//the node data accessed from the getElement() method
				MazeNode elem = getElement(area);
				int lifePoints = elem.getLifePoints();
				//add lifePoints
				hero1.gainPoint(lifePoints); 
				//conditions for if the hero has enough lifePoints at a certain stage in path
				if(hero1.getLifePoints() >= 0 && j == oneLongPath.size() - 1) 
				{
					validPathList.add(oneLongPath);
				}
				else if(hero1.getLifePoints() <= 0 && j != longPaths.size()-1)
				{
					break;
				}
				//decrease lifePoints
				hero1.losePoint(); 
			}
			//reset the lifePoints after the iteration of the nested for loop
			hero1.resetLives();
		}
		printValidPaths(validPathList);
	}
	/**
	 * This method prints all the valid paths found in the validPaths() method in a label + " " + label... format
	 * @param ArrayList<ArrayList<Node>> validPList - the valid paths ArrayList of ArrayLists
	 */
	private void printValidPaths(ArrayList<ArrayList<Node>> validPList)
	{
		for(int i = 0; i < validPList.size(); i++)
		{
			ArrayList<Node> aPath = validPList.get(i);
			for(int j = 0; j < aPath.size(); j++)
			{
				Node node = aPath.get(j);
				//prints the valid paths
				System.out.print(getElement(node).getLabel() + " "); 
			}
			System.out.println();
		} 
	}
}
