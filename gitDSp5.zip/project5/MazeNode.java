package project5;
/**
 * The MazeNode class represents the nodes of the maze and this class able to access life points as well as the node label.
 * It implements comparable (type MazeNode) and compares the node labels to find the correct order.
 * In addition to two private instance variables, MazeNode class contains a constructor, two getter methods, and a compareTo method.
 * @author Katherine Han
 * @version 04/30/2023
 */
public class MazeNode implements Comparable<MazeNode>{
	private String label;
	private int lifePoints;
	/**
	 * MazeNode constructor constructs the MazeNode to consist of a label and life points
	 * @param String label - the label of the MazeNode
	 * @param int lifePoints - the number of lifePoints at that MazeNode
	 */
	public MazeNode(String label, int lifePoints)
	{
		this.label = label;
		this.lifePoints = lifePoints;
	}
	/**
	 * This is a getter method for the MazeNode's label
	 * @return the String label
	 */
	public String getLabel()
	{
		return this.label;
	}
	/**
	 * This is a getter method for the MazeNode's lifePoints
	 * @return the int lifePoints
	 */
	public int getLifePoints()
	{
		return this.lifePoints;
	}
	/**
	 * This is a compareTo method for the MazeNode's label
	 * @return the int compareTo value when comparing the input label
	 */
	@Override
	public int compareTo(MazeNode node)
	{
		if(node == null)
		{
			throw new NullPointerException("null value");
		}
		return this.label.compareTo(node.label);
	}
}
